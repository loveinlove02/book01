from dotenv import load_dotenv
import os
from langchain_openai import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.prompts import PromptTemplate

import streamlit as st
from whisper import whisper_stt

from openai import OpenAI
import base64

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

embeddings = OpenAIEmbeddings(
    openai_api_key=key,
    model='text-embedding-ada-002'
)

database = Chroma(
    persist_directory = './data', 
    embedding_function = embeddings
)

def ask(query):
    documents = database.similarity_search(query)

    document_string = ''    

    for document in documents:
        document_string += f"""
-------------------------------
{document.page_content}
"""
    template="""문장을 바탕으로 질문에 답하세요.
    문장: {document}
    질문: {query}
    """

    prompt = PromptTemplate(
        template=template, 
        input_variables=['document', 'query']
    )

    llm = ChatOpenAI(
        api_key=key, 
        model='gpt-4o',
        temperature=0
    )

    
    chain = prompt | llm

    return chain.invoke({'document': document_string, 'query': query})


def text_to_audtio(client, text):
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text,
    )

    response.stream_to_file("audio.mp3")


def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        md = f"""
            <audio controls autoplay="true">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
            """
        st.markdown(
            md,
            unsafe_allow_html=True,
        )


st.title("💬 AI 도서 Chatbot")
st.caption("🚀 AI chatbot 입니다")


if "messages" not in st.session_state:
    st.session_state["messages"] = [
                                        {'role':'system', 'content': '당신은 훌룽한 도우미 입니다. 한국어로 답변해주세요.'},
                                        {"role": "assistant", "content": "안녕하세요 무엇을 도와드릴까요?"}
                                   ]
    
for msg in st.session_state.messages:
    if msg['role'] != 'system':
        st.chat_message(msg['role']).write(msg['content'])


if prompt := whisper_stt(openai_api_key=key, language = 'ko'):
    client = OpenAI(api_key=key)
    
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)
    
    response = ask(prompt)
    msg = response.content
    
    text_to_audtio(client, msg)
    # st.audio("audio.mp3")

    st.session_state.messages.append({"role": "assistant", "content": msg})
    st.chat_message("assistant").write(msg)
    autoplay_audio("audio.mp3")


