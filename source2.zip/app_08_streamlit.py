import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os



load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')


st.title("💬 AI 도서 Chatbot")
st.caption("🚀 AI chatbot 입니다")


if "messages" not in st.session_state:
    st.session_state["messages"] = [
                                        {'role':'system', 'content': '당신은 훌룽한 도우미 입니다. 한국어로 답변해주세요.'},
                                        {"role": "assistant", "content": "안녕하세요 무엇을 도와드릴까요?"}
                                   ]

for msg in st.session_state.messages:
    if msg['role'] != 'system':
        st.chat_message(msg['role']).write(msg['content'])

if prompt := st.chat_input():
    client = OpenAI(api_key=key)
    
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    response = client.chat.completions.create(model="gpt-4o", messages=st.session_state.messages)
    msg = response.choices[0].message.content
    
    st.session_state.messages.append({"role": "assistant", "content": msg})
    st.chat_message("assistant").write(msg)