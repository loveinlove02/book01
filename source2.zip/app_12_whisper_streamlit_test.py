import streamlit as st
from whisper import whisper_stt

from dotenv import load_dotenv
import os

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

text = whisper_stt(openai_api_key=key, language = 'ko')  

if text:
    st.write(text)




# https://pypi.org/project/streamlit-mic-recorder/