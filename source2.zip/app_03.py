from dotenv import load_dotenv
import os
from openai import OpenAI

load_dotenv(verbose=True)
key = os.getenv('OPENAI_API_KEY')

client = OpenAI(api_key=key)

def ask(question, message=[], model='gpt-3.5-turbo-1106'):

    # 첫 번째 질문인 경우
    if len(message) == 0:
        message.append({'role':'system', 'content': 'You are a helpful assistant. Answer in Korean.'})
    
    # 사용자 질문을 리스트에 추가하기
    message.append({'role':'user', 'content': question})

    # 답변 만들기
    completion = client.chat.completions.create(
        model=model,
        messages=message,
    )

    # 답변을 다시 리스트에 추가하기
    message.append({'role':'assistant', 'content': completion.choices[0].message.content})

    return message

answer=[]


while True:
    user_content = input('user : ')

    answer = ask(user_content, message=answer)
    print(answer[-1]['content'] + '\n')
