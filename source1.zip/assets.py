class Assets():
    def __init__(self):
        self.bg_color = '#B8D1F5'
